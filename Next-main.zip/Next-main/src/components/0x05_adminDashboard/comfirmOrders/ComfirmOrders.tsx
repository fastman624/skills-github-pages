import "./ComfirmOrders.scss";

const ComfirmOrders = () => {
	return <div>ComfirmOrders</div>;
};

export default ComfirmOrders;
