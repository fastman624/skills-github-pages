import "./Ticket.scss";

const Ticket = () => {
	return <div>Ticket</div>;
};

export default Ticket;
