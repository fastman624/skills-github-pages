import "./Reply.scss";

const Reply = () => {
	return <div>Reply</div>;
};

export default Reply;
