import "./Sidemenu.scss";

const Sidemenu = () => {
	return <div>Sidemenu</div>;
};

export default Sidemenu;
