import "./ComfirmPayout.scss";

const ComfirmPayout = () => {
	return <div>ComfirmPayout</div>;
};

export default ComfirmPayout;
